# Boids as implemented here

The accompanying Wikipedia article describes the general model. This describes *this*
simulation, which differs from the textbook version in ways that matter if you intend to
reason about — or reproduce — what the photographs show. Everything below is stated in the
source under `code/`; nothing here is extra behaviour.

## Where it departs from the standard model

| standard boids | here |
| --- | --- |
| continuous heading, steered by a force vector | **64 discrete headings**, one step per tick |
| acceleration, variable speed | **constant speed**, fixed by the scenario |
| floating-point positions | **integer pixel positions** |
| omnidirectional perception | **240° field of view**, 120° blind arc behind |
| one neighbourhood radius | **two**: separation is much shorter-range than cohesion and alignment |
| open or wrapping space | **walls**, enforced by a veto that can override any decision |
| all boids updated simultaneously | **sequential**, in index order |

The steering force is not applied to a velocity. It is used only to *rank three candidate
headings*, and the best-ranked one is taken whole. A boid either turns one step left, holds
straight, or turns one step right.

## The numbers

From `Params.java`. Lengths are functions of the scenario's turning radius `r`, not
constants, so that the physics and the navigation map can never disagree about how tightly
a boid turns.

| quantity | value |
| --- | --- |
| headings | 64, so one step is **5.625°** |
| a full turn | 64 ticks, **independent of `r`** |
| speed | `2·r·sin(π/64)` per tick |
| separation radius | `1.25 · r` |
| cohesion / alignment radius | `3.75 · r` |
| field of view | `cos(fov) = -0.5`, i.e. 240° forward, 120° blind arc |
| weights | separation **120**, alignment **70**, cohesion **30** |
| straight-bias | `(120+30+70)/64 = 3.4375` |

Because a full turn always takes 64 ticks regardless of `r`, a duration expressed in ticks
means the same thing in every scenario. The radius sets how much ground a turn covers, not
how long it takes.

## How one boid decides

`MovementLogic.calculate`, for boid *i*:

1. **Gather neighbours.** For every other boid *j*: skip it if it is coincident, if it is
   further than the cohesion/alignment radius, or if it falls in the blind arc — the test is
   `dx·cos(h) + dy·sin(h) < -0.5·d`, so anything more than 120° off the heading is unseen.
2. **Accumulate three vectors** over the neighbours that survive:
   - **cohesion** — sum of offsets to each neighbour
   - **alignment** — sum of each neighbour's *heading unit vector*
   - **separation** — sum of offsets away from neighbours closer than the separation
     radius, each scaled by a linear falloff `(rSep − d)/rSep`, which is 1 at contact and 0
     at the rim
3. **Normalise each of the three to unit length, then weight it.** Normalising first is what
   makes the weights comparable: a rule with one contributing neighbour is not amplified
   against one with twenty. Sum the three into a desired direction.
4. **If no neighbour contributed, hold the current heading** and stop.
5. **Score three candidates** — hold, one step left, one step right — by the dot product of
   that heading's unit vector with the desired direction, adding the straight-bias to *hold*
   only. Take the highest.

The straight-bias is hysteresis. Without it a boid whose desired direction sits almost
exactly between two headings alternates left-right every tick, which renders as a visible
tremor.

**Ties are resolved by evaluation order and a strict comparison**: candidates are tried in
the order hold, left, right, and a later candidate must *strictly* beat the incumbent. So
hold wins ties against both turns, and left wins ties against right. This is part of the
definition, not an accident — changing it changes every timeline.

## What happens after the decision

`Boids2DEngine.tick`, for each boid in index order:

1. the flocking rules propose a turn
2. anything steering this boid may overrule them
3. the proposal is **clamped to −1, 0 or +1**
4. the **collision veto** takes the proposal if it keeps the boid alive, otherwise
   substitutes the nearest turn that does
5. the turn is applied, **then** the boid advances one step along its **new** heading

Two consequences worth being explicit about. The veto does not know what proposed the turn,
so a boid being steered is subject to exactly the same limits as one that is not. And the
turn precedes the move, so a boid's displacement on a tick is along the heading it ends the
tick with, not the one it began with.

**Boids move one at a time, in index order.** When boid *i* decides, boids before it have
already moved this tick and boids after it have not. A simultaneous update would be
symmetric, and under a symmetric update two boids that ever arrive at the same position and
heading would remain identical forever.

## Walls

`NavMapBuilder` precomputes, for the play area at a given turning radius, which
`(x, y, heading)` states a boid can survive from — meaning some sequence of turns keeps it
inside the area forever. A move is legal only if **every pixel along its step** is in play,
not merely the endpoint, so a boid can never cross a wall thinner than its stride.

`NavMap.constrainTurn` returns the proposed turn when it survives, and otherwise the nearest
one that does — trying straight before the opposite turn. Boids start only in survivable
states, and a survivable state always has a survivable successor, so no boid can ever leave
the play area.

## The scenarios

| | map | `r` | boids | speed/tick | separation | cohesion & alignment |
| --- | --- | --- | --- | --- | --- | --- |
| HAMBURGER | `hamburger.png` | 20 | 10 | 1.963 | 25 | 75 |
| DAB | `dab.png` | 40 | 4 | 3.925 | 50 | 150 |
| BLOSSOM | `blossom.png` | 40 | 10 | 3.925 | 50 | 150 |

Maps are PNGs under `code/areas/`. **Pure black is out of bounds; `#FF7F27` is the scoring
zone; everything else is open play area.** Rendered images recolour these — see the legend
in each case's instructions — but the source maps use the values above.

## Why this matters for reading the photographs

Boids are drawn as triangles whose nose points along the direction of travel. Position and
heading are therefore both visible, and position plus heading *is* the entire state of a
boid — there is no hidden velocity, momentum or internal variable.

The simulation is deterministic. The same state always produces the same next state. So a
complete flock state read off one image determines every subsequent image, and the rules
that do the determining are in `code/` in full.
