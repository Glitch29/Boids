# Resources

Reference material, bundled so it is available without a network connection.

| file | what it is |
| --- | --- |
| `boids-wikipedia.pdf` | The Wikipedia article "Boids", saved as a PDF. General background: Craig Reynolds' 1986 model, the three steering rules, history and applications. Text from Wikipedia is licensed **CC BY-SA 4.0** (https://creativecommons.org/licenses/by-sa/4.0/); see the article's own history page for contributor attribution. |
| `this-implementation.md` | Written for this packet. How the simulation under `code/` differs from the general model, with the exact constants, the decision procedure, and the tick order. |

If you want to see flocking in motion, the screenshots in `cases/` are a better source than
any general-purpose video would be: they come from this simulation, on these maps, with
these constants.

Start with `this-implementation.md` if you only read one. The Wikipedia article describes
boids in general; the simulation you are looking at makes several specific choices —
discrete headings, a blind arc behind each boid, two different neighbourhood radii, a wall
veto, and sequential rather than simultaneous updates — and those choices are what the
photographs actually show.

The authoritative description is always the source under `code/`. Where this documentation
and the code disagree, the code is right.
