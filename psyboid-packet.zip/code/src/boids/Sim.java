package boids;

import java.io.IOException;

/**
 * A simulation and the states it produces.
 * <p>
 * The engine holds nothing that changes as a run proceeds, so one instance can drive any
 * number of independent timelines concurrently.
 * <p>
 * Leaving the play area carries no special handling — a boid out of bounds is steered by
 * the navigation map like any other. Leaving the <em>image</em> is fatal and throws.
 */
public final class Sim {

    private final Engine engine;

    public Sim(ScenarioParameter parameter) throws IOException {
        engine = new Boids2DEngine(parameter);
    }

    /** A fresh timeline from a seed, at tick 0 with no score. */
    public State start(long seed) {
        return engine.init(seed);
    }

    /** One tick on, leaving the argument untouched. */
    public State step(State state) {
        return engine.tick(state);
    }

    /** Repeated {@link #step}, until the state reaches {@code targetTick}. */
    public State advanceTo(State state, long targetTick) {
        State s = state;
        while (s.tick < targetTick) s = engine.tick(s);
        return s;
    }

    /**
     * One instant of a timeline: every boid's position and heading, and the tick.
     * <p>
     * Treat instances as immutable. The arrays are exposed directly rather than copied,
     * because the decision layer reads them in its inner loop and a copy per access would
     * dominate the cost. Nothing writes to a {@code State} once it has been constructed —
     * {@link Engine#tick} allocates fresh arrays and returns a new instance.
     */
    public static final class State {

        public final int n;

        public final int[] x;
        public final int[] y;

        /** Heading as an index into {@link Params#COS} / {@link Params#SIN}. */
        public final int[] h;

        public final long tick;

        /** Boid-ticks spent inside the scoring zone, summed over the flock. */
        public final long score;

        /**
         * Score accumulated by each boid individually; sums to {@link #score}.
         * <p>
         * Kept alongside the total because a boid that simply parks itself in the scoring
         * zone and one whose gain comes from moving the rest of the flock look identical
         * in the total and nothing alike here.
         */
        public final long[] boidScore;

        /** Identifies which timeline this came from; carried through every tick untouched. */
        public final String label;

        /**
         * Controls that act between the flocking rules and the collision veto.
         * <p>
         * Empty in an ordinary run: every boid simply follows the rules. A boid that
         * deviates from them does so through here, and the ordering is the point —
         * whatever occupies this slot writes the same one-step turn an ordinary boid
         * writes, into the same field, and is then handed to the same
         * {@link NavMap#constrainTurn} veto. There is no way to steer a boid that is not
         * subject to the physics every other boid is subject to.
         */
        public final MovementControl[] steering;

        public State(int n, int[] x, int[] y, int[] h, long tick, long score,
                     long[] boidScore, String label, MovementControl... steering) {
            this.n = n;
            this.x = x;
            this.y = y;
            this.h = h;
            this.tick = tick;
            this.score = score;
            this.boidScore = boidScore;
            this.label = label;
            this.steering = steering;
        }
    }
}
