package boids;

import java.lang.Override;
import java.nio.file.Path;

/**
 * The scenarios cases are drawn from: a play area, the turning radius its navigation was
 * built for, and a flock size.
 */
public enum PresetScenarioParameter implements ScenarioParameter {
    HAMBURGER ("hamburger.png", 20f, 10),
    DAB ("dab.png", 40f, 4),
    BLOSSOM ("blossom.png", 40f, 10);

    private final String filename;
    private final float r;
    private final int n;

    PresetScenarioParameter(String filename, float r, int n) {
        this.filename = filename;
        this.r = r;
        this.n = n;
    }

    @Override
    public Path mapPath() {
        return Path.of("areas", filename);
    }

    @Override
    public float turningRadius() {
        return r;
    }

    @Override
    public int flockSize() {
        return n;
    }
}