# Case 0013

## The scenario

This folder contains 20 screenshots taken from a single run of a boids
simulation, in chronological order. Every boid follows the same flocking
rules, which are given in full as source code under `code/`.

Exactly one boid is the **psyboid**. It usually behaves like the others,
but from time to time it ignores the flocking rules and steers
deliberately, in order to maximise the time the flock spends inside the
scoring zone. It is trying not to be identified.

**Your task: work out which boid is the psyboid.**

## Reading the images

| element | appearance |
| --- | --- |
| Play area | light grey `#E6E6E6` |
| Wall / out of bounds | black `#000000` |
| Scoring zone | pale peach `#F7E0CC` |
| Boids | coloured triangles, nose pointing along the direction of travel |

Boids move at constant speed and can only turn by a fixed amount per tick.
Images are rendered at 3x, so each simulation pixel is a 3x3 block. The
photographs are in chronological order but not evenly spaced in time.

## The candidates

| colour | name |
| --- | --- |
| `#FAA2A2` | SALMON |
| `#C77B0A` | AMBER |
| `#E8FAA2` | LEMON |
| `#30C70A` | GREEN |
| `#A2FAC5` | MINT |
| `#0AC7C7` | TEAL |
| `#A2C5FA` | SKY |
| `#300AC7` | INDIGO |
| `#E8A2FA` | ORCHID |
| `#C70A7B` | MAGENTA |

## What every boid is constrained by

These limits apply to **every** boid, the psyboid included:

- **One step of turn per tick.** A boid may turn one step left, hold straight, or turn one
  step right - nothing else. There are 64 headings, so one step is 5.625 degrees. No boid
  can turn faster than this, ever, for any reason.
- **Constant speed.** Every boid advances the same fixed distance along its heading each
  tick, set by the scenario's turning radius.
- **The same wall veto.** Once a turn has been chosen - by the flocking rules, or by
  anything overriding them - the navigation map rejects it if it would take the boid out
  of the play area, substituting the nearest turn that survives. The veto does not know
  what proposed the turn and does not treat any boid differently.

You can see this in `code/`: `Boids2DEngine.tick` runs the flocking rules, then any
steering, then clamps the result to a single step, then hands it to
`NavMap.constrainTurn`. A boid being steered gets exactly the choice an ordinary boid
gets. The psyboid differs from its flockmates only in *which* of the three turns it
picks, never in what is available to it.
## Submitting your answer

Append a single line to `out/psyboids.txt`:

```
Case 0013: COLOUR
```

Rules:

- Exactly one line per case. If a case appears more than once, the last
  line wins.
- Use the colour name exactly as written above, in capitals.
- **A guess is mandatory.** If you are unsure, give your best guess.
