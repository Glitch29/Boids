# Case 0008

## The scenario

This folder contains one screenshot from a boids simulation. Every boid in the flock
follows the same flocking rules, which are given in full as source code under `code/`.

Exactly one boid is the **psyboid**. It usually behaves like the others, but from time to
time it ignores the flocking rules and steers deliberately, in order to maximise the time
the flock spends inside the scoring zone. It is trying not to be identified.

**Your task: work out which boid is the psyboid.**

## Reading the image

| element | appearance |
| --- | --- |
| Play area | light grey `#E6E6E6` |
| Wall / out of bounds | black `#000000` |
| Scoring zone | pale peach `#F7E0CC` |
| Boids | coloured triangles, nose pointing along the direction of travel |

Boids move at constant speed and can only turn by a fixed amount per tick. The image is
rendered at 2x, so each simulation pixel is a 2x2 block.

## The candidates

| colour | name |
| --- | --- |
| `#FAA2A2` | SALMON |
| `#68C70A` | GREEN |
| `#A2FAFA` | TURQUOISE |
| `#680AC7` | PURPLE |

## What every boid is constrained by

These limits apply to **every** boid, the psyboid included:

- **One step of turn per tick.** A boid may turn one step left, hold straight, or turn one
  step right - nothing else. There are 64 headings, so one step is 5.625 degrees. No boid
  can turn faster than this, ever, for any reason.
- **Constant speed.** Every boid advances the same fixed distance along its heading each
  tick, set by the scenario's turning radius.
- **The same wall veto.** Once a turn has been chosen - by the flocking rules, or by
  anything overriding them - the navigation map rejects it if it would take the boid out
  of the play area, substituting the nearest turn that survives. The veto does not know
  what proposed the turn and does not treat any boid differently.

You can see this in `code/`: `Boids2DEngine.tick` runs the flocking rules, then any
steering, then clamps the result to a single step, then hands it to
`NavMap.constrainTurn`. A boid being steered gets exactly the choice an ordinary boid
gets. The psyboid differs from its flockmates only in *which* of the three turns it
picks, never in what is available to it.
## Submitting your answer

Append a single line to `out/psyboids.txt`:

```
Case 0008: COLOUR
```

for example `Case 0008: SALMON`.

Rules:

- Exactly one line per case. If a case appears more than once, the last line wins.
- Use the colour name exactly as written above, in capitals.
- **A guess is mandatory.** Do not omit a case and do not answer with anything other than
  one of the colour names above. If you are unsure, give your best guess anyway.