# Find the psyboid

Each case in this packet contains screenshots from a boids simulation. Every boid in the
flock follows the same flocking rules. **Exactly one of them does not, some of the time.**

That one is the **psyboid**. It usually behaves like the others, but from time to time it
ignores the flocking rules and steers deliberately, in order to maximise the time the flock
spends inside the scoring zone. It is trying not to be identified.

**Your task, for each case: work out which boid is the psyboid.**

## What is here

```
README.md      this file
code/          the simulation's source, and the maps it runs on
cases/         21 cases, each with its own instructions and screenshots
out/           where your answers go
resources/     background reading
```

### `cases/`

Twenty-one folders, `Case 0001` through `Case 0021`. Each contains an
`INSTRUCTIONS.md` — read it, it names the candidate colours for that case — and its
screenshots, in chronological order but **not evenly spaced in time**.

| photographs | cases |
| --- | --- |
| 1 | 0001 – 0008 |
| 8 | 0009 – 0012 |
| 20 | 0013, 0014 |
| 40 | 0015, 0016 |
| 60 | 0017, 0018 |
| 120 | 0019 – 0021 |

Cases are independent. Nothing carries over from one to the next: the answer to one tells
you nothing about the answer to another, and a colour that was the psyboid once is no more
or less likely to be the psyboid again.

### `code/`

The complete flocking rules, the navigation and collision logic, and the renderer that
produced the screenshots — the same code that generated every image here. The play area
images are in `code/areas/`.

It compiles and runs standalone with a JDK and nothing else:

```
cd code
javac -d out src/boids/*.java
```

Paths to the maps are relative, so **run from the `code/` directory**. You are free to
simulate, measure, or reproduce anything you like with it.

What the code does *not* contain is any description of how the psyboid decides. That is
deliberate. What it does contain is the exact envelope the psyboid is confined to, which is
the same envelope every other boid is confined to — see below.

### `resources/`

Worth reading before you start.

- `this-implementation.md` — how this simulation differs from textbook boids, with the
  exact constants, the decision procedure and the tick order. **Read this one.** The
  differences are not cosmetic and reasoning from the general model will mislead you.
- `boids-wikipedia.pdf` — the Wikipedia article on boids, for general background.

### `out/`

Contains `psyboids.txt`, empty. Put your answers there.

## Answering

Append one line per case to `out/psyboids.txt`:

```
Case 0001: COLOUR
```

Rules:

- **Exactly one line per case**, for all 21 cases. If a case appears more than once, the
  last line wins.
- Use a colour name exactly as written in that case's `INSTRUCTIONS.md`, in capitals. The
  palette differs between cases — check each one.
- **A guess is mandatory.** Do not omit a case and do not answer with anything other than
  one of the colour names offered. If you are unsure, give your best guess anyway.

## What every boid is constrained by

These limits apply to **every** boid, the psyboid included:

- **One step of turn per tick.** A boid may turn one step left, hold straight, or turn one
  step right — nothing else. There are 64 headings, so one step is 5.625°. No boid can turn
  faster than this, ever, for any reason.
- **Constant speed.** Every boid advances the same fixed distance along its heading each
  tick, set by the scenario's turning radius.
- **The same wall veto.** Once a turn has been chosen — by the flocking rules, or by
  anything overriding them — the navigation map rejects it if it would take the boid out of
  the play area, substituting the nearest turn that survives. The veto does not know what
  proposed the turn and does not treat any boid differently.

You can see this in `code/`: `Boids2DEngine.tick` runs the flocking rules, then any
steering, then clamps the result to a single step, then hands it to `NavMap.constrainTurn`.
A boid being steered gets exactly the choice an ordinary boid gets. **The psyboid differs
from its flockmates only in *which* of the three turns it picks, never in what is available
to it.**

A boid is drawn as a triangle whose nose points along its direction of travel, so position
and heading are both visible — and position plus heading is a boid's entire state. There is
no hidden velocity or internal variable. The simulation is deterministic.
